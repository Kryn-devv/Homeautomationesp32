#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "APPLE";
const char* password = "3672@Bhagat";

#define RELAY1 18
#define RELAY2 19
#define RELAY3 21
#define RELAY4 22

WebServer server(80);

bool relay1State = false;
bool relay2State = false;
bool relay3State = false;
bool relay4State = false;

void relayOff(int pin) {
  digitalWrite(pin, HIGH);
}

void relayOn(int pin) {
  digitalWrite(pin, LOW);
}

String dashboardPage() {
  String ip = WiFi.localIP().toString();

  String page = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Friday Home</title>
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: Arial, Helvetica, sans-serif;
      color: #17212b;
      background:
        radial-gradient(circle at top left, rgba(0, 180, 216, 0.20), transparent 30%),
        linear-gradient(135deg, #f7fafc 0%, #e7eef5 100%);
    }
    .shell {
      width: min(980px, calc(100% - 28px));
      margin: 0 auto;
      padding: 26px 0;
    }
    header {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 18px;
      margin-bottom: 22px;
    }
    h1 {
      margin: 0;
      font-size: clamp(30px, 6vw, 56px);
      line-height: 0.95;
      letter-spacing: 0;
    }
    .subtitle {
      margin: 10px 0 0;
      color: #5d6c7b;
      font-size: 15px;
    }
    .ip {
      padding: 10px 13px;
      border: 1px solid rgba(23, 33, 43, 0.12);
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.72);
      color: #354555;
      font-size: 13px;
      white-space: nowrap;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px;
    }
    .card {
      border: 1px solid rgba(23, 33, 43, 0.10);
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.82);
      box-shadow: 0 18px 45px rgba(39, 54, 68, 0.11);
      padding: 18px;
    }
    .device-top {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      align-items: center;
      margin-bottom: 16px;
    }
    .device-name {
      margin: 0;
      font-size: 22px;
    }
    .pin {
      color: #6a7a8a;
      font-size: 12px;
      margin-top: 4px;
    }
    .status {
      min-width: 58px;
      padding: 6px 10px;
      border-radius: 999px;
      background: #eef2f6;
      color: #627080;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
    }
    .status.on {
      background: #dff8eb;
      color: #087846;
    }
    .buttons {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 10px;
    }
    button {
      border: 0;
      border-radius: 8px;
      padding: 13px 12px;
      font-size: 15px;
      font-weight: 800;
      cursor: pointer;
      transition: transform 120ms ease, opacity 120ms ease;
    }
    button:active { transform: scale(0.98); }
    .on-btn {
      background: #0b8f5a;
      color: white;
    }
    .off-btn {
      background: #dfe6ee;
      color: #263340;
    }
    .danger {
      width: 100%;
      margin-top: 14px;
      background: #17212b;
      color: white;
      padding: 15px;
    }
    .footer {
      margin-top: 14px;
      color: #657586;
      font-size: 13px;
      text-align: center;
    }
    @media (max-width: 700px) {
      header {
        display: block;
      }
      .ip {
        display: inline-block;
        margin-top: 16px;
      }
      .grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <main class="shell">
    <header>
      <div>
        <h1>Friday Home</h1>
        <p class="subtitle">ESP32 relay control panel</p>
      </div>
      <div class="ip">IP: )rawliteral";

  page += ip;
  page += R"rawliteral(</div>
    </header>

    <section class="grid">
      <article class="card" data-device="light">
        <div class="device-top">
          <div><h2 class="device-name">Light</h2><div class="pin">Relay 1 - GPIO 18</div></div>
          <div class="status" id="lightStatus">OFF</div>
        </div>
        <div class="buttons">
          <button class="on-btn" onclick="setRelay('light', 'on')">ON</button>
          <button class="off-btn" onclick="setRelay('light', 'off')">OFF</button>
        </div>
      </article>

      <article class="card" data-device="fan">
        <div class="device-top">
          <div><h2 class="device-name">Fan</h2><div class="pin">Relay 2 - GPIO 19</div></div>
          <div class="status" id="fanStatus">OFF</div>
        </div>
        <div class="buttons">
          <button class="on-btn" onclick="setRelay('fan', 'on')">ON</button>
          <button class="off-btn" onclick="setRelay('fan', 'off')">OFF</button>
        </div>
      </article>

      <article class="card" data-device="appliance">
        <div class="device-top">
          <div><h2 class="device-name">Appliance</h2><div class="pin">Relay 3 - GPIO 21</div></div>
          <div class="status" id="applianceStatus">OFF</div>
        </div>
        <div class="buttons">
          <button class="on-btn" onclick="setRelay('appliance', 'on')">ON</button>
          <button class="off-btn" onclick="setRelay('appliance', 'off')">OFF</button>
        </div>
      </article>

      <article class="card" data-device="relay4">
        <div class="device-top">
          <div><h2 class="device-name">Relay 4</h2><div class="pin">GPIO 22</div></div>
          <div class="status" id="relay4Status">OFF</div>
        </div>
        <div class="buttons">
          <button class="on-btn" onclick="setRelay('relay4', 'on')">ON</button>
          <button class="off-btn" onclick="setRelay('relay4', 'off')">OFF</button>
        </div>
      </article>
    </section>

    <button class="danger" onclick="allOff()">ALL RELAYS OFF</button>
    <div class="footer" id="message">Ready</div>
  </main>

  <script>
    const names = ['light', 'fan', 'appliance', 'relay4'];

    function paint(data) {
      names.forEach(name => {
        const badge = document.getElementById(name + 'Status');
        const isOn = !!data[name];
        badge.textContent = isOn ? 'ON' : 'OFF';
        badge.className = 'status' + (isOn ? ' on' : '');
      });
    }

    async function setRelay(device, action) {
      const message = document.getElementById('message');
      message.textContent = 'Sending...';
      try {
        await fetch('/' + device + '/' + action);
        await refreshStatus();
        message.textContent = device.toUpperCase() + ' ' + action.toUpperCase();
      } catch (error) {
        message.textContent = 'Command failed';
      }
    }

    async function allOff() {
      const message = document.getElementById('message');
      message.textContent = 'Turning everything off...';
      try {
        await fetch('/all/off');
        await refreshStatus();
        message.textContent = 'All relays are OFF';
      } catch (error) {
        message.textContent = 'Command failed';
      }
    }

    async function refreshStatus() {
      const response = await fetch('/status');
      const data = await response.json();
      paint(data);
    }

    refreshStatus();
    setInterval(refreshStatus, 3000);
  </script>
</body>
</html>
)rawliteral";

  return page;
}

String statusJson() {
  String json = "{";
  json += "\"light\":";
  json += relay1State ? "true" : "false";
  json += ",\"fan\":";
  json += relay2State ? "true" : "false";
  json += ",\"appliance\":";
  json += relay3State ? "true" : "false";
  json += ",\"relay4\":";
  json += relay4State ? "true" : "false";
  json += "}";
  return json;
}

void setup() {
  Serial.begin(115200);

  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  pinMode(RELAY3, OUTPUT);
  pinMode(RELAY4, OUTPUT);

  relayOff(RELAY1);
  relayOff(RELAY2);
  relayOff(RELAY3);
  relayOff(RELAY4);
  relay1State = false;
  relay2State = false;
  relay3State = false;
  relay4State = false;

  Serial.println();
  Serial.println("=== FRIDAY HOME CONTROLLER ===");

  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connected!");
  Serial.print("HOME ESP32 IP: ");
  Serial.println(WiFi.localIP());

  server.on("/", []() {
    server.send(200, "text/html", dashboardPage());
  });

  server.on("/status", []() {
    server.send(200, "application/json", statusJson());
  });

  server.on("/light/on", []() {
    relayOn(RELAY1);
    relay1State = true;
    server.send(200, "text/plain", "LIGHT ON");
  });

  server.on("/light/off", []() {
    relayOff(RELAY1);
    relay1State = false;
    server.send(200, "text/plain", "LIGHT OFF");
  });

  server.on("/fan/on", []() {
    relayOn(RELAY2);
    relay2State = true;
    server.send(200, "text/plain", "FAN ON");
  });

  server.on("/fan/off", []() {
    relayOff(RELAY2);
    relay2State = false;
    server.send(200, "text/plain", "FAN OFF");
  });

  server.on("/appliance/on", []() {
    relayOn(RELAY3);
    relay3State = true;
    server.send(200, "text/plain", "APPLIANCE ON");
  });

  server.on("/appliance/off", []() {
    relayOff(RELAY3);
    relay3State = false;
    server.send(200, "text/plain", "APPLIANCE OFF");
  });

  server.on("/relay4/on", []() {
    relayOn(RELAY4);
    relay4State = true;
    server.send(200, "text/plain", "RELAY 4 ON");
  });

  server.on("/relay4/off", []() {
    relayOff(RELAY4);
    relay4State = false;
    server.send(200, "text/plain", "RELAY 4 OFF");
  });

  server.on("/all/off", []() {
    relayOff(RELAY1);
    relayOff(RELAY2);
    relayOff(RELAY3);
    relayOff(RELAY4);
    relay1State = false;
    relay2State = false;
    relay3State = false;
    relay4State = false;

    server.send(200, "text/plain", "ALL OFF");
  });

  server.begin();

  Serial.println("Home controller server started!");
}

void loop() {
  server.handleClient();
}
